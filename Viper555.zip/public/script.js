const form = document.getElementById("searchForm");
const input = document.getElementById("phone");
const button = document.getElementById("searchButton");
const statusBox = document.getElementById("status");
const resultsBox = document.getElementById("results");

form.addEventListener("submit", async (event) => {
  event.preventDefault();

  const phone = input.value.trim();
  if (!phone) return;

  button.disabled = true;
  statusBox.textContent = "جاري البحث...";
  resultsBox.innerHTML = "";

  try {
    const response = await fetch("/api/search", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ phone })
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.error || "حدث خطأ.");
    }

    statusBox.textContent = `تم العثور على ${data.count} نتيجة عامة.`;

    if (!data.results.length) {
      resultsBox.innerHTML =
        '<div class="empty">لم تظهر نتائج عامة مفهرسة لهذا الرقم.</div>';
      return;
    }

    for (const item of data.results) {
      const article = document.createElement("article");
      article.className = "result";

      const link = document.createElement("a");
      link.href = item.url;
      link.target = "_blank";
      link.rel = "noopener noreferrer";
      link.textContent = item.title;

      const description = document.createElement("p");
      description.textContent = item.description;

      article.appendChild(link);
      article.appendChild(description);
      resultsBox.appendChild(article);
    }
  } catch (error) {
    statusBox.textContent = error.message;
  } finally {
    button.disabled = false;
  }
});