# فحص ظهور رقم الجوال

تطبيق Node.js + Express بواجهة عربية RTL للبحث في صفحات الويب العامة المفهرسة عن رقم جوال.

## التشغيل

```bash
npm install
```

أنشئ متغير البيئة:

```text
BRAVE_API_KEY=your_key
```

ثم:

```bash
npm start
```

## Render

- Environment: Node
- Build Command: `npm install`
- Start Command: `npm start`
- Environment Variable: `BRAVE_API_KEY`

لا تضع مفتاح Brave داخل ملفات `public/` أو داخل JavaScript الخاص بالمتصفح.

التطبيق يبحث فقط في الويب العام المفهرس ولا يحاول الوصول إلى حسابات أو قواعد بيانات خاصة.
