const express = require("express");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json({ limit: "32kb" }));
app.use(express.static("public"));

function normalizePhone(input) {
  return String(input || "").trim().replace(/[^\d+]/g, "");
}

function digitsOnly(phone) {
  return phone.replace(/\D/g, "");
}

app.post("/api/search", async (req, res) => {
  try {
    if (!process.env.BRAVE_API_KEY) {
      return res.status(500).json({
        error: "BRAVE_API_KEY غير مضبوط في إعدادات الخادم."
      });
    }

    const phone = normalizePhone(req.body?.phone);

    if (!phone || digitsOnly(phone).length < 6) {
      return res.status(400).json({
        error: "أدخل رقم جوال صحيحًا."
      });
    }

    const digits = digitsOnly(phone);
    const queries = [...new Set([
      `"${phone}"`,
      `"${digits}"`
    ])];

    const results = [];

    for (const q of queries) {
      const url = new URL("https://api.search.brave.com/res/v1/web/search");
      url.searchParams.set("q", q);
      url.searchParams.set("count", "10");
      url.searchParams.set("safesearch", "strict");

      const response = await fetch(url, {
        headers: {
          "Accept": "application/json",
          "X-Subscription-Token": process.env.BRAVE_API_KEY
        }
      });

      if (!response.ok) {
        const text = await response.text();
        console.error("Brave API error:", response.status, text);
        return res.status(502).json({
          error: "تعذر الاتصال بخدمة البحث حاليًا."
        });
      }

      const data = await response.json();

      for (const item of (data.web?.results || [])) {
        if (!item.url) continue;
        results.push({
          title: item.title || "بدون عنوان",
          url: item.url,
          description: item.description || ""
        });
      }
    }

    const unique = Array.from(
      new Map(results.map(item => [item.url, item])).values()
    ).slice(0, 20);

    res.json({
      phone,
      count: unique.length,
      results: unique,
      note: "هذه نتائج من صفحات عامة مفهرسة على الويب فقط، وليست نتيجة تؤكد ملكية الرقم أو ارتباطه بحساب."
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      error: "حدث خطأ غير متوقع في الخادم."
    });
  }
});

app.get("*", (req, res) => {
  res.sendFile("index.html", { root: "public" });
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});